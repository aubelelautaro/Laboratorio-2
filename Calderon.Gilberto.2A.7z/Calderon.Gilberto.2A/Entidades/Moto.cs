﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Moto:Vehiculo
    {
        #region Atributos
        public ECilindrada cilindrada;
        #endregion

        #region Constructores
        public Moto(string marca, EPais pais, string modelo, float precio, ECilindrada cilindrada):base(marca,pais, modelo, precio)
        {
            this.cilindrada = cilindrada;
        }
        #endregion

        #region Sobrecarga de operadores
        public static implicit operator Single(Moto m)
        {
            return m.precio;
        }

        public static bool operator ==(Moto a, Moto b)
        {
            if(!(a is null) && !(b is null))
            {
                if((Vehiculo) a == (Vehiculo)b && a.cilindrada == b.cilindrada)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Moto a, Moto b)
        {
            return !(a == b);
        }
        #endregion

        #region Metodos
        public override bool Equals(object obj)
        {
            if(obj is Moto && (Moto)obj == this)
            {
                return true;
            }
            return false;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append((string)((Vehiculo)this));
            sb.AppendLine($"Cilindrada: {this.cilindrada}");
            return sb.ToString();
        }
        #endregion
    }
}
