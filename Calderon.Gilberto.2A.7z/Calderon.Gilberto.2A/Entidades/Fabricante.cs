﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Fabricante
    {
        #region Atributos
        private string marca;
        private EPais pais;
        #endregion

        public Fabricante(string marca, EPais pais)
        {
            this.marca = marca;
            this.pais = pais;
        }

        #region Sobrecarga de operadore
        public static implicit operator string(Fabricante f)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Marca: {f.marca} - {f.pais}");
            return sb.ToString();
        }

        public static bool operator ==(Fabricante a, Fabricante b)
        {
            if(!(a is null) && !(b is null))
            {
                if(String.Compare(a.marca, b.marca) == 0 && a.pais == b.pais)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Fabricante a, Fabricante b)
        {
            return !(a == b);
        }
        #endregion
    }
}
