﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Vehiculo
    {
        #region Atributos
        protected Fabricante fabricante;
        protected static Random generadorDeVelocidades;
        protected string modelo;
        protected float precio;
        protected int velocidadMaxima;
        #endregion

        #region Propiedades
        public int VelocidadMaxima
        {
            get
            {
               this.velocidadMaxima = Vehiculo.generadorDeVelocidades.Next(100, 281);
               return this.velocidadMaxima;  
            }
        }
        #endregion

        #region Constructores
        static Vehiculo()
        {
            Vehiculo.generadorDeVelocidades = new Random();
        }

        public Vehiculo(float precio, string modelo, Fabricante fabri)
        {
            this.precio = precio;
            this.modelo = modelo;
            this.fabricante = fabri;
            this.velocidadMaxima = this.VelocidadMaxima;
        }

        public Vehiculo(string marca, EPais pais, string modelo, float precio):this(precio, modelo, new Fabricante(marca, pais))
        {

        }
        #endregion

        #region Metodos
        private static string Mostrar(Vehiculo v)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(v.fabricante);
            sb.AppendLine($"Modelo: {v.modelo}");
            sb.AppendLine($"Velocidad Maxima: {v.velocidadMaxima}");
            sb.AppendLine($"Precio: {v.precio}");
            return sb.ToString();
        }

        public static explicit operator string(Vehiculo v)
        {
            return Vehiculo.Mostrar(v);
        }

        public static bool operator ==(Vehiculo a, Vehiculo b)
        {
            if(!(a is null) && !(b is null))
            {
                if(string.Compare(a.modelo, b.modelo) == 0 && a.fabricante == b.fabricante)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Vehiculo a, Vehiculo b)
        {
            return !(a == b);
        }
        #endregion
    }
}
