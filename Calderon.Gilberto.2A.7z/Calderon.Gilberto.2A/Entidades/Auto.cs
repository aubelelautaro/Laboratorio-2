﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Auto: Vehiculo
    {
        #region Atributos
        public ETipo tipo;
        #endregion

        #region Constructores
        public Auto(string modelo, float precio, Fabricante fabri, ETipo tipo):base(precio, modelo, fabri)
        {
            this.tipo = tipo;
        }
        #endregion

        #region Sobrecarga de operadore
        public static bool operator ==(Auto a, Auto b)
        {
            if(!(a is null) && !(b is null))
            {
                if(a.tipo == b.tipo && (Vehiculo)a == (Vehiculo)b)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Auto a, Auto b)
        {
            return !(a == b);
        }

        public static explicit operator Single(Auto a)
        {
            return a.precio;
        }
        #endregion

        #region Metodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append((string)((Vehiculo)this));
            sb.AppendLine($"Tipo: {this.tipo}");
            return sb.ToString();
        }

        public override bool Equals(object obj)
        {
            if(obj is Auto && (Auto)obj == this)
            {
                return true;
            }
            return false;
        }
        #endregion
    }
}
